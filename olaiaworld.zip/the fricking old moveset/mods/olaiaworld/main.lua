-- name: OlaiaMoveset
-- description: Olaiaworld but olaia haves old moveset from the beta testing, now 	you need commands to activate olaia and all characters except olaia are gone (it was the only way to make olaia work with the old moveset), Models by \\#f6f930\\JustOlaia
ACT_SECOND_JUMP =					allocate_mario_action(ACT_FLAG_AIR | ACT_FLAG_ALLOW_VERTICAL_WIND_ACTION)
ACT_WALL_SLIDE =                  	allocate_mario_action(ACT_FLAG_AIR | ACT_FLAG_MOVING | ACT_FLAG_ALLOW_VERTICAL_WIND_ACTION)
ACT_WALL_CLIMB =                  	allocate_mario_action(ACT_FLAG_AIR | ACT_FLAG_MOVING | ACT_FLAG_ALLOW_VERTICAL_WIND_ACTION)

E_MODEL_OLAIA_PLAYER = smlua_model_util_get_id("olaia_geo")
gStateExtras = {}
for i=0,(MAX_PLAYERS-1) do
    gStateExtras[i] = {}
    local m = gMarioStates[i]
    local e = gStateExtras[i]
	e.animFrame = 0
    e.sprinting = 0
	e.sprintspeed = 0
	e.maxsprint = 20
	e.diveslidetimer = 0
	
    e.lastPos = {}
    e.lastPos.x = m.pos.x
    e.lastPos.y = m.pos.y
    e.lastPos.z = m.pos.z
	
    e.savedWallSlideHeight = 0
    e.savedWallSlide = false
	
	e.lastforwardVel = 0
end

function hatkid_command(msg)
    if gMarioStates[0].character.type == 3 and msg == 'on' then
        djui_chat_message_create('\\#ff0000\\You cannot be \\##00ffff\\Waluigi\\#ff0000\\ for this Echo Character! (Nobody likes him.)')
        return true
	elseif gMarioStates[0].character.type == 3 and msg == 'off' then
		djui_chat_message_create('\\#ff0000\\You cannot be \\##00ffff\\Waluigi\\#ff0000\\ for this Echo Character! (Nobody likes him.)')
		return true		
    end
    if msg == 'on' then
        djui_chat_message_create('Olaia\\#ffffff\\ is \\#00C7FF\\on\\#ffffff\\!')
        gPlayerSyncTable[0].modelId = E_MODEL_OLAIA_PLAYER
        return true
    elseif msg == 'off' then
        djui_chat_message_create('Olaia\\#ffffff\\ is \\#A02200\\off\\#ffffff\\!')
        gPlayerSyncTable[0].modelId = nil
        return true
    end
    return false
end

function mario_update_local(m)
    if gMarioStates[0].character.type == 3 then
		gPlayerSyncTable[0].modelId = nil
	end
end

function mario_on_set_action(m)
    local e = gStateExtras[m.playerIndex]
	if gPlayerSyncTable[0].modelId == E_MODEL_OLAIA_PLAYER then
	if m.action == ACT_GROUND_POUND and m.flags & (MARIO_METAL_CAP) == 0 then
		if m.vel.y <= 0 then
			m.vel.y = 30
		end
		m.forwardVel =	m.forwardVel + 20
        m.particleFlags = m.particleFlags | PARTICLE_MIST_CIRCLE
		return set_mario_action(m, ACT_DIVE, 0)
	end
	if m.prevAction == ACT_WALKING and (m.input & INPUT_Z_PRESSED) ~= 0 then
		if m.vel.y <= 0 then
			m.vel.y = 30
		end
		m.forwardVel =	m.forwardVel + 20
        m.particleFlags = m.particleFlags | PARTICLE_MIST_CIRCLE
		return set_mario_action(m, ACT_DIVE, 0)
	end
	if (m.input & INPUT_B_PRESSED) ~= 0 and m.action == ACT_DIVE and m.prevAction ~= ACT_GROUND_POUND then 
		set_mario_action(m, ACT_JUMP_KICK, 0)
	end
	if m.action == ACT_DOUBLE_JUMP then
	   set_mario_action(m, ACT_JUMP, 0)
	end
	if m.action == ACT_SECOND_JUMP then
		m.vel.y = 50
	end
    if m.action == ACT_FORWARD_ROLLOUT and e.diveslidetimer <= 3 then
		m.particleFlags = m.particleFlags | PARTICLE_SPARKLES
		return set_mario_action(m, ACT_TOP_OF_POLE_JUMP, 0)
    end
    if m.action == ACT_SOFT_BONK then
        m.faceAngle.y = m.faceAngle.y + 0x8000
        m.pos.x = e.lastPos.x
        m.pos.y = e.lastPos.y
        m.pos.z = e.lastPos.z
        set_mario_action(m, ACT_WALL_CLIMB, 0)
		if e.lastforwardVel > 0 then
			m.vel.y = e.lastforwardVel + 5
		else
			m.vel.y = 0
		end
	end
	end
end

function mario_before_phys_step(m)
    local e = gStateExtras[m.playerIndex]
	if gPlayerSyncTable[0].modelId == E_MODEL_OLAIA_PLAYER then
	if m.action == ACT_WALKING and m.forwardVel >= 30 then
		m.forwardVel = m.forwardVel + e.sprintspeed
		if (m.controller.buttonDown & B_BUTTON) ~= 0 then
			e.sprinting = 1
		else
			e.sprinting = 0
		end
	end
	if e.sprinting ~= 0 and e.sprintspeed <= e.maxsprint then
		e.sprintspeed = e.sprintspeed + 0.5
	elseif e.sprinting == 0 then
		e.sprintspeed = e.sprintspeed - 1
	end
	if e.sprintspeed >= e.maxsprint then
		if (m.action & ACT_FLAG_AIR) == 0 then
			m.particleFlags = m.particleFlags | PARTICLE_DUST
		end
		if m.action == ACT_JUMP then
			if m.flags & (MARIO_WING_CAP) ~= 0 then
				set_mario_action(m, ACT_FLYING_TRIPLE_JUMP, 0)
			else
				set_mario_action(m, ACT_TRIPLE_JUMP, 0)
			end
		end
	end
	if e.sprintspeed <= 0 then e.sprintspeed = 0 end
	end
end

function mario_update(m)
    local e = gStateExtras[m.playerIndex]
    if m.playerIndex == 0 then
        mario_update_local(m)
    end
	if gPlayerSyncTable[0].modelId == E_MODEL_OLAIA_PLAYER then
	local saveflag = save_file_get_flags()
    if m.action == ACT_JUMP and m.actionTimer > 0 and (m.controller.buttonPressed & A_BUTTON) ~= 0 then
        set_mario_action(m, ACT_SECOND_JUMP, 0)
    end
	
    if m.action == ACT_JUMP then
        m.actionTimer = m.actionTimer + 1
    end
	
	if m.action == ACT_GROUND_POUND and m.flags & (MARIO_METAL_CAP) ~= 0 and (m.controller.buttonPressed & B_BUTTON) ~= 0 then
		m.vel.y = 30
		m.forwardVel =	m.forwardVel + 20
        m.particleFlags = m.particleFlags | PARTICLE_MIST_CIRCLE
		set_mario_action(m, ACT_DIVE, 0)
	end
	
	if (saveflag & SAVE_FLAG_HAVE_METAL_CAP) ~= 0 then
		if (m.controller.buttonPressed & L_JPAD) ~= 0 then
			m.flags = m.flags | MARIO_METAL_CAP
			m.flags = m.flags & ~MARIO_WING_CAP & ~MARIO_VANISH_CAP
		end
	end
	if (saveflag & SAVE_FLAG_HAVE_WING_CAP) ~= 0 then
		if (m.controller.buttonPressed & U_JPAD) ~= 0 then
			m.flags = m.flags | MARIO_WING_CAP
			m.flags = m.flags & ~MARIO_METAL_CAP & ~MARIO_VANISH_CAP
		end
	end	
	if (saveflag & SAVE_FLAG_HAVE_VANISH_CAP) ~= 0 then
		if (m.controller.buttonPressed & R_JPAD) ~= 0 then
			m.flags = m.flags | MARIO_VANISH_CAP
			m.flags = m.flags & ~MARIO_METAL_CAP & ~MARIO_WING_CAP
		end
	end
	if (m.controller.buttonPressed & D_JPAD) ~= 0 then
		m.flags = m.flags & ~MARIO_WING_CAP & ~MARIO_METAL_CAP & ~MARIO_VANISH_CAP
	end	
	
    if m.action == ACT_DIVE_SLIDE then
        e.diveslidetimer = e.diveslidetimer + 1
	elseif m.action ~= ACT_DIVE_SLIDE and m.action ~= ACT_FORWARD_ROLLOUT then
		e.diveslidetimer = 0
    end
	
    -- save last pos
    e.lastPos.x = m.pos.x
    e.lastPos.y = m.pos.y
    e.lastPos.z = m.pos.z
	if m.forwardVel >= 0 then
		e.lastforwardVel = m.forwardVel
	end
    if (m.action & ACT_FLAG_AIR) ~= 0 and m.vel.y <= 0 then
        m.vel.y = m.vel.y + 2
    end
	end
	
    if gPlayerSyncTable[m.playerIndex].modelId ~= nil then
        obj_set_model_extended(m.marioObj, gPlayerSyncTable[m.playerIndex].modelId)
    end
	return 0
end

function act_second_jump(m)
    local e = gStateExtras[m.playerIndex]
    if check_kick_or_dive_in_air(m) ~= 0 then
        return 1
    end

    if (m.input & INPUT_Z_PRESSED) ~= 0 then
        return set_mario_action(m, ACT_GROUND_POUND, 0)
    end

    if m.actionTimer == 0 then
		e.animFrame = 0
        m.particleFlags = m.particleFlags | PARTICLE_MIST_CIRCLE
    end

    common_air_action_step(m, ACT_JUMP_LAND, MARIO_ANIM_FORWARD_FLIP,
                           AIR_STEP_CHECK_LEDGE_GRAB | AIR_STEP_CHECK_HANG)
	set_anim_to_frame(m, e.animFrame)
	if e.animFrame >= m.marioObj.header.gfx.animInfo.curAnim.loopEnd then
		e.animFrame = m.marioObj.header.gfx.animInfo.curAnim.loopEnd
	end
	
	m.marioObj.header.gfx.angle.y = m.marioObj.header.gfx.angle.y + 0x18000
	e.animFrame = e.animFrame + 1

    m.actionTimer = m.actionTimer + 1

    return 0
end

function act_wall_climb(m)
    local e = gStateExtras[m.playerIndex]
    e.savedWallSlideHeight = m.pos.y
    e.savedWallSlide = true

    if (m.input & INPUT_A_PRESSED) ~= 0 then
        m.vel.y = 52.0
        -- m.faceAngle.y = m.faceAngle.y + 0x8000
        return set_mario_action(m, ACT_WALL_KICK_AIR, 0)
    end

    -- attempt to stick to the wall a bit. if it's 0, sometimes you'll get kicked off of slightly sloped walls
    mario_set_forward_vel(m, -1.0)

    m.particleFlags = m.particleFlags | PARTICLE_DUST

    play_sound(SOUND_MOVING_TERRAIN_SLIDE + m.terrainSoundAddend, m.marioObj.header.gfx.cameraToObject)
    set_mario_animation(m, MARIO_ANIM_CRAWLING)
	set_anim_to_frame(m, e.animFrame)
	if e.animFrame >= m.marioObj.header.gfx.animInfo.curAnim.loopEnd then
		e.animFrame = 0
	end

    if perform_air_step(m, 0) == AIR_STEP_LANDED then
        mario_set_forward_vel(m, 0.0)
        if check_fall_damage_or_get_stuck(m, ACT_HARD_BACKWARD_GROUND_KB) == 0 then
            return set_mario_action(m, ACT_FREEFALL_LAND, 0)
        end
    end

    m.actionTimer = m.actionTimer + 1
    if m.wall == nil and m.actionTimer > 2 then
        mario_set_forward_vel(m, 0.0)
        return set_mario_action(m, ACT_FREEFALL, 0)
    end
	
	if m.vel.y <= 0 then
        m.pos.x = e.lastPos.x
        m.pos.y = e.lastPos.y
        m.pos.z = e.lastPos.z
        set_mario_action(m, ACT_WALL_SLIDE, 0)
        m.vel.x = 0
        m.vel.y = 0
        m.vel.z = 0
	end

    -- gravity
    m.vel.y = m.vel.y + 2
	m.peakHeight = m.vel.y
	m.marioObj.header.gfx.angle.x = -0x36000
	m.marioObj.header.gfx.angle.y = m.marioObj.header.gfx.angle.y + 0x18000
	e.animFrame = e.animFrame + 3

    return 0
end

function act_wall_slide(m)
    local e = gStateExtras[m.playerIndex]
    e.savedWallSlideHeight = m.pos.y
    e.savedWallSlide = true

    if (m.input & INPUT_A_PRESSED) ~= 0 then
        m.vel.y = 52.0
        -- m.faceAngle.y = m.faceAngle.y + 0x8000
        return set_mario_action(m, ACT_WALL_KICK_AIR, 0)
    end

    -- attempt to stick to the wall a bit. if it's 0, sometimes you'll get kicked off of slightly sloped walls
    mario_set_forward_vel(m, -1.0)

    m.particleFlags = m.particleFlags | PARTICLE_DUST

    play_sound(SOUND_MOVING_TERRAIN_SLIDE + m.terrainSoundAddend, m.marioObj.header.gfx.cameraToObject)
    set_mario_animation(m, MARIO_ANIM_START_WALLKICK)

    if perform_air_step(m, 0) == AIR_STEP_LANDED then
        mario_set_forward_vel(m, 0.0)
        if check_fall_damage_or_get_stuck(m, ACT_HARD_BACKWARD_GROUND_KB) == 0 then
            return set_mario_action(m, ACT_FREEFALL_LAND, 0)
        end
    end

    m.actionTimer = m.actionTimer + 1
    if m.wall == nil and m.actionTimer > 2 then
        mario_set_forward_vel(m, 0.0)
        return set_mario_action(m, ACT_FREEFALL, 0)
    end

    -- gravity
	m.peakHeight = m.vel.y
	if m.vel.y <= -30 then m.vel.y = -30 end

    return 0
end

-----------
-- hooks --
-----------
hook_event(HOOK_MARIO_UPDATE, mario_update)
hook_event(HOOK_ON_SET_MARIO_ACTION, mario_on_set_action)
hook_event(HOOK_BEFORE_PHYS_STEP, mario_before_phys_step)

hook_mario_action(ACT_SECOND_JUMP, act_second_jump)
hook_mario_action(ACT_WALL_SLIDE, act_wall_slide)
hook_mario_action(ACT_WALL_CLIMB, act_wall_climb)
hook_chat_command('olaia', "just the olaiaworld mod but with the old moveset, i added it just if someone wants it (i think yes because kanheaven leaved a round of olaiaworld when he discovered moveset was gone in v2 lol), type /olaia on or off", hatkid_command)