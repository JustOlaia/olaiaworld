local HP_TO_HEAL_COUNTER_UNITS_FACTOR = 1 / 0x40
local MAX_HP_IN_HEAL_COUNTER_UNITS = 0x880 * HP_TO_HEAL_COUNTER_UNITS_FACTOR

local function on_interact(interactor, interactee, interactType, interactValue)
    --FUTURE: add back original condition when it's fixed in source
    --if not interactValue or interactType ~= INTERACT_STAR_OR_KEY then
    if interactType ~= INTERACT_STAR_OR_KEY or interactor.playerIndex ~= 0 then
        return
    end
    
    --FUTURE: exclude stuff that's already collected when source makes it possible
    
    interactor.hurtCounter = 0
    interactor.healCounter = MAX_HP_IN_HEAL_COUNTER_UNITS
        - interactor.health * HP_TO_HEAL_COUNTER_UNITS_FACTOR
end

hook_event(HOOK_ON_INTERACT, on_interact)