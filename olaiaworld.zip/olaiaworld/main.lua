-- name: \\#00db96\\OlaiaWorld
-- description: Adds 2 custom characters.\n\ \n\Type /olaiaworld \\#4ffd3c\\character \\#ffffff\\or\\#A02200\\ off\\#ffffff\\ to use the characters!\n\ \n\Models by \\#f6f930\\JustOlaia.

-- Olaia
E_MODEL_BERDLY_CHAR = smlua_model_util_get_id("olaia_geo")

-- Diego
E_MODEL_NOELLE_CHAR = smlua_model_util_get_id("diego_geo")

local type = 0

function deltarune64_command(msg)
	-- This is Terrible
    if gMarioStates[0].character.type ~= 0 and msg == 'olaia' then
        djui_chat_message_create('\\#ff0000\\You need to be \\#e4000f\\Mario\\#ff0000\\ for this Character!')
        return true
	elseif gMarioStates[0].character.type ~= 0 and msg == 'diego' then
		djui_chat_message_create('\\#ff0000\\You need to be \\#e4000f\\Mario\\#ff0000\\ for this Character!')
		return true
    elseif gMarioStates[0].character.type ~= 0 and msg == 'off' then
		djui_chat_message_create('\\#FFFF00\\You need to be Mario for this Character!')
		return true
    end

	-- Olaia
	if msg == 'olaia' then
		djui_chat_message_create('\\#f6f930\\Olaia\\#ffffff\\ is \\#4ffd3c\\on\\#ffffff\\!')
		type = 1
		return true
	elseif msg == 'diego' then
		djui_chat_message_create('\\#00ecff\\Diego\\#ffffff\\ is \\#4ffd3c\\on\\#ffffff\\!')
		type = 2
		return true
	elseif msg == 'off' then
		djui_chat_message_create('\\#0000ff\\OlaiaWorld\\#ffffff\\ is \\#A02200\\off\\#ffffff\\!')
		type = 0
		return true
	end

    return false
end

function mario_update_local(m)
	-- Olaia
    if type == 1 then
        if gMarioStates[0].character.type == 0 then
            gPlayerSyncTable[0].modelId = E_MODEL_BERDLY_CHAR
        end
      -- Diego
    elseif type == 2 then
        if gMarioStates[0].character.type == 0 then
            gPlayerSyncTable[0].modelId = E_MODEL_NOELLE_CHAR
        end
    end

	-- Turn off our model if requested
    if gMarioStates[0].character.type ~= 0 or type == 0 then
		gPlayerSyncTable[0].modelId = nil
	end
end

function mario_update(m)
    if m.playerIndex == 0 then
        mario_update_local(m)
    end

    if gPlayerSyncTable[m.playerIndex].modelId ~= nil then
        obj_set_model_extended(m.marioObj, gPlayerSyncTable[m.playerIndex].modelId)
    end
end

-----------
-- hooks --
-----------
hook_event(HOOK_MARIO_UPDATE, mario_update)

hook_chat_command('olaiaworld', "turn any character to olaia or diego, to get olaia type /olaiaworld olaia, to get diego type /olaiaworld diego.", deltarune64_command)