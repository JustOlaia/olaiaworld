-- credits to swagh

function a()
    hud_hide()
end

hook_event(HOOK_ON_HUD_RENDER, a)