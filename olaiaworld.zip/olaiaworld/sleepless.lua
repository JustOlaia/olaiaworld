function mario_update(m)
    if (m.action == ACT_START_SLEEPING) then
        set_mario_action(m, ACT_WAKING_UP, 0)
    end
end
hook_event(HOOK_MARIO_UPDATE, mario_update)